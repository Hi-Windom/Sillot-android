# SiYuan appearance <a title="Hits" target="_blank" href="https://github.com/siyuan-note/appearance"><img src="https://hits.b3log.org/siyuan-note/appearance.svg"></a>

[中文](https://github.com/siyuan-note/appearance/blob/master/README.md)

* emojis: Emoji assets
* langs: Multi-language configuration
* themes: Appearance themes
* icons: Appearance icons
