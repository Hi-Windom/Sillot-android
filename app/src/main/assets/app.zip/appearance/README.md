# 思源笔记外观 <a title="Hits" target="_blank" href="https://github.com/siyuan-note/appearance"><img src="https://hits.b3log.org/siyuan-note/appearance.svg"></a>

[English](https://github.com/siyuan-note/appearance/blob/master/README_en_US.md)

* emojis：Emoji 表情
* langs：多语言配置
* themes：主题
* icons：图标
